const devStored = require('./devStored');
const devMem = require('./devMem');

module.exports = {
  devStored,
  devMem,
};
